"""Claude Command Center — Monitor and manage Claude Code sessions in tmux."""

__version__ = "0.1.0"
